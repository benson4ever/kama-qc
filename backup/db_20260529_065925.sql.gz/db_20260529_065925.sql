--
-- PostgreSQL database dump
--

\restrict I1KkP1gkcW8Itf9sxMMgm4w0ZxmkphA1RNk3XmVPuNZreVW3m9krgfpOjw5bFnB

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: set_updated_at(); Type: FUNCTION; Schema: public; Owner: kama
--

CREATE FUNCTION public.set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$BEGIN NEW.updated_at = now(); RETURN NEW; END;$$;


ALTER FUNCTION public.set_updated_at() OWNER TO kama;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: defects; Type: TABLE; Schema: public; Owner: kama
--

CREATE TABLE public.defects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code text NOT NULL,
    name_en text NOT NULL,
    name_zh text,
    classification text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT defects_classification_check CHECK ((classification = ANY (ARRAY['major'::text, 'minor'::text])))
);


ALTER TABLE public.defects OWNER TO kama;

--
-- Name: inspection_issue_photos; Type: TABLE; Schema: public; Owner: kama
--

CREATE TABLE public.inspection_issue_photos (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    inspection_issue_id uuid NOT NULL,
    file_path text NOT NULL,
    caption text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.inspection_issue_photos OWNER TO kama;

--
-- Name: inspection_issues; Type: TABLE; Schema: public; Owner: kama
--

CREATE TABLE public.inspection_issues (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    inspection_id uuid NOT NULL,
    defect_id uuid,
    custom_description text,
    pcs_found integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT inspection_issues_defect_or_custom CHECK (((defect_id IS NOT NULL) OR (custom_description IS NOT NULL)))
);


ALTER TABLE public.inspection_issues OWNER TO kama;

--
-- Name: inspections; Type: TABLE; Schema: public; Owner: kama
--

CREATE TABLE public.inspections (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    supplier_id uuid NOT NULL,
    po_number text,
    date_from date,
    date_to date,
    type text NOT NULL,
    total_order_qty integer,
    total_inspected integer,
    result text NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT inspections_result_check CHECK ((result = ANY (ARRAY['pass'::text, 'fail'::text]))),
    CONSTRAINT inspections_type_check CHECK ((type = ANY (ARRAY['inline'::text, 'final'::text])))
);


ALTER TABLE public.inspections OWNER TO kama;

--
-- Name: pgmigrations; Type: TABLE; Schema: public; Owner: kama
--

CREATE TABLE public.pgmigrations (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    run_on timestamp without time zone NOT NULL
);


ALTER TABLE public.pgmigrations OWNER TO kama;

--
-- Name: pgmigrations_id_seq; Type: SEQUENCE; Schema: public; Owner: kama
--

CREATE SEQUENCE public.pgmigrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pgmigrations_id_seq OWNER TO kama;

--
-- Name: pgmigrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kama
--

ALTER SEQUENCE public.pgmigrations_id_seq OWNED BY public.pgmigrations.id;


--
-- Name: pp_sample_photos; Type: TABLE; Schema: public; Owner: kama
--

CREATE TABLE public.pp_sample_photos (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    pp_sample_id uuid NOT NULL,
    file_path text NOT NULL,
    caption text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.pp_sample_photos OWNER TO kama;

--
-- Name: pp_samples; Type: TABLE; Schema: public; Owner: kama
--

CREATE TABLE public.pp_samples (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    supplier_id uuid NOT NULL,
    po_number text,
    style_id text,
    fit text,
    issues_text text,
    result text NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT pp_samples_result_check CHECK ((result = ANY (ARRAY['approved'::text, 'not_approved'::text])))
);


ALTER TABLE public.pp_samples OWNER TO kama;

--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: kama
--

CREATE TABLE public.suppliers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    name_zh text,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.suppliers OWNER TO kama;

--
-- Name: users; Type: TABLE; Schema: public; Owner: kama
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email public.citext NOT NULL,
    name text,
    name_zh text,
    password_hash text NOT NULL,
    role text DEFAULT 'staff'::text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT users_role_check CHECK ((role = ANY (ARRAY['admin'::text, 'staff'::text])))
);


ALTER TABLE public.users OWNER TO kama;

--
-- Name: pgmigrations id; Type: DEFAULT; Schema: public; Owner: kama
--

ALTER TABLE ONLY public.pgmigrations ALTER COLUMN id SET DEFAULT nextval('public.pgmigrations_id_seq'::regclass);


--
-- Data for Name: defects; Type: TABLE DATA; Schema: public; Owner: kama
--

COPY public.defects (id, code, name_en, name_zh, classification, sort_order, active, created_at) FROM stdin;
fccf191b-0639-45f7-be8b-9fe7ecd919a3	holes	Holes	破洞	major	1	t	2026-05-29 13:40:32.698584+00
0d851106-3742-4cff-90d5-3287814606ed	elastic_exposed	Elastic exposed	橡筋外露	major	2	t	2026-05-29 13:40:32.700852+00
f2994cde-cb75-42ac-8782-355afbb12759	elastic_damaged	Elastic damaged	橡筋破损	major	3	t	2026-05-29 13:40:32.701929+00
abfe51e0-b950-409a-af4f-f0bb3b37fa3d	spandex_exposed	Spandex exposed	氨纶丝外露	major	4	t	2026-05-29 13:40:32.702996+00
b1ee7e5d-b7e3-46c9-b36c-04b7faa02329	leg_stretch	Leg opening stretch out of spec	脚口拉伸超标	major	5	t	2026-05-29 13:40:32.703997+00
0d4da760-0522-445d-9c6f-fdc81f31e84a	measurement_tolerance	Measurements out of tolerance	尺寸超公差	major	6	t	2026-05-29 13:40:32.705062+00
c0710a9d-fe88-4205-a650-4d2b56615035	front_deformed	Front panel deformed	前U变形	major	7	t	2026-05-29 13:40:32.706205+00
c499d0e4-cb58-4e24-b151-cbf6734b13d0	mesh_distorted	Back mesh panel distorted	后幅网布变形	major	8	t	2026-05-29 13:40:32.707613+00
bc95093f-e6f5-43d8-9f9e-fd2b264384ab	size_label_damaged	Size label damaged	小标破损	major	9	t	2026-05-29 13:40:32.70881+00
0288e6fc-5282-46a3-b96e-56af479d5f6c	care_label_issue	Care label issues	洗水唛问题	major	10	t	2026-05-29 13:40:32.710025+00
db388a53-99ab-4247-af2b-5e92d1ebdc17	skipped_stitch	Skipped stitches	跳针	major	11	t	2026-05-29 13:40:32.711242+00
272392b0-b1bc-42e8-b95a-dd4649802e5b	four_needle_six_thread	Four-needle six-thread issue	四针六线问题	major	12	t	2026-05-29 13:40:32.712778+00
d2ab2d0e-e39a-4c50-a7d8-e08685000d7a	oil_stain_major	Oil stain / dirt (large)	油污/脏污（大）	major	13	t	2026-05-29 13:40:32.713841+00
fcbcbce2-b59b-41fb-9937-a55b20185511	loose_threads	Loose threads	线头	minor	14	t	2026-05-29 13:40:32.714959+00
d3acf360-599a-4cfb-992f-f83f38e49a0e	raw_edges	Raw edges	毛边	minor	15	t	2026-05-29 13:40:32.715884+00
3fe8848f-c7b4-40ce-9d01-e3c861ef124d	trimming_excess	Trimming excess	飞边	minor	16	t	2026-05-29 13:40:32.71679+00
fb72550c-764e-4deb-9e23-2823ab1157d7	snag	Snag	勾丝	minor	17	t	2026-05-29 13:40:32.717725+00
9e22502e-cf94-41af-a56d-a80a72082d14	elastic_snag	Elastic snag	橡筋勾丝	minor	18	t	2026-05-29 13:40:32.718815+00
392293a6-f6d6-4376-ba20-a2f3b4853ce8	front_misaligned	Front panel misaligned	前U歪斜	minor	19	t	2026-05-29 13:40:32.720161+00
0a2b2351-6e47-4d28-a00f-7aaed41095f4	front_rippling	Front panel rippling	前U起浪	minor	20	t	2026-05-29 13:40:32.722701+00
5f37f936-64b0-4051-912a-50f7eb292cec	mesh_off_center	Back mesh panel off-center	后幅网布不居中	minor	21	t	2026-05-29 13:40:32.723802+00
db03f0db-20df-4b72-b057-3bdd24fbf757	size_label_crooked	Size label crooked/bubbling	小标歪斜/鼓包	minor	22	t	2026-05-29 13:40:32.724712+00
26f96dd6-61d5-4ca8-a18b-d3fddf7f585d	uneven_overlock	Uneven overlock	重线不齐	minor	23	t	2026-05-29 13:40:32.725707+00
845b3556-92d7-4bda-8650-eddaeaa0cfde	mixed_yarn	Mixed/coarse yarn	杂纱/粗纱	minor	24	t	2026-05-29 13:40:32.726722+00
62d8ae3e-21f9-403b-a424-5f8cf3ee5ad5	brand_label_issue	Brand label issues	祺唛问题	minor	25	t	2026-05-29 13:40:32.727691+00
8e67c648-bde9-4e4c-bce0-e21b7683da05	oil_stain_minor	Oil stain (small)	油污/脏污（小）	minor	26	t	2026-05-29 13:40:32.728539+00
1d6cb4d0-1c6e-47a7-bc31-21a71b073529	needle_holes	Needle holes	针孔	minor	27	t	2026-05-29 13:40:32.729429+00
19ef5ab0-ed65-41fd-95d8-c47c4570cbf3	creases	Creases/wrinkles	皱褶	minor	28	t	2026-05-29 13:40:32.730316+00
\.


--
-- Data for Name: inspection_issue_photos; Type: TABLE DATA; Schema: public; Owner: kama
--

COPY public.inspection_issue_photos (id, inspection_issue_id, file_path, caption, created_at) FROM stdin;
\.


--
-- Data for Name: inspection_issues; Type: TABLE DATA; Schema: public; Owner: kama
--

COPY public.inspection_issues (id, inspection_id, defect_id, custom_description, pcs_found, created_at) FROM stdin;
\.


--
-- Data for Name: inspections; Type: TABLE DATA; Schema: public; Owner: kama
--

COPY public.inspections (id, supplier_id, po_number, date_from, date_to, type, total_order_qty, total_inspected, result, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: pgmigrations; Type: TABLE DATA; Schema: public; Owner: kama
--

COPY public.pgmigrations (id, name, run_on) FROM stdin;
1	1716000000000_init	2026-05-29 13:40:32.530054
\.


--
-- Data for Name: pp_sample_photos; Type: TABLE DATA; Schema: public; Owner: kama
--

COPY public.pp_sample_photos (id, pp_sample_id, file_path, caption, created_at) FROM stdin;
\.


--
-- Data for Name: pp_samples; Type: TABLE DATA; Schema: public; Owner: kama
--

COPY public.pp_samples (id, supplier_id, po_number, style_id, fit, issues_text, result, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: kama
--

COPY public.suppliers (id, name, name_zh, active, created_at) FROM stdin;
ca7ee0d8-42cf-4c5a-b34a-28fa0c18b006	Zhongshan Best	\N	t	2026-05-29 13:40:32.689477+00
f4267ccb-fab8-4226-8d63-07d5da6cec64	Dongguan Longest	\N	t	2026-05-29 13:40:32.696182+00
55fa7808-8406-4c32-87ad-e30fb6358466	Nantong Tianhong	\N	t	2026-05-29 13:40:32.697502+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: kama
--

COPY public.users (id, email, name, name_zh, password_hash, role, active, created_at) FROM stdin;
76460039-8758-497f-9536-0299d28d3d5b	karl@kama-textiles.com	Karl	\N	$2a$10$8109OfVqqSnykxFOwl3GqefmeBC73EEf/oaf0HirNIdmWsDeTWleO	admin	t	2026-05-29 13:40:32.914735+00
\.


--
-- Name: pgmigrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kama
--

SELECT pg_catalog.setval('public.pgmigrations_id_seq', 1, true);


--
-- Name: defects defects_code_key; Type: CONSTRAINT; Schema: public; Owner: kama
--

ALTER TABLE ONLY public.defects
    ADD CONSTRAINT defects_code_key UNIQUE (code);


--
-- Name: defects defects_pkey; Type: CONSTRAINT; Schema: public; Owner: kama
--

ALTER TABLE ONLY public.defects
    ADD CONSTRAINT defects_pkey PRIMARY KEY (id);


--
-- Name: inspection_issue_photos inspection_issue_photos_pkey; Type: CONSTRAINT; Schema: public; Owner: kama
--

ALTER TABLE ONLY public.inspection_issue_photos
    ADD CONSTRAINT inspection_issue_photos_pkey PRIMARY KEY (id);


--
-- Name: inspection_issues inspection_issues_pkey; Type: CONSTRAINT; Schema: public; Owner: kama
--

ALTER TABLE ONLY public.inspection_issues
    ADD CONSTRAINT inspection_issues_pkey PRIMARY KEY (id);


--
-- Name: inspections inspections_pkey; Type: CONSTRAINT; Schema: public; Owner: kama
--

ALTER TABLE ONLY public.inspections
    ADD CONSTRAINT inspections_pkey PRIMARY KEY (id);


--
-- Name: pgmigrations pgmigrations_pkey; Type: CONSTRAINT; Schema: public; Owner: kama
--

ALTER TABLE ONLY public.pgmigrations
    ADD CONSTRAINT pgmigrations_pkey PRIMARY KEY (id);


--
-- Name: pp_sample_photos pp_sample_photos_pkey; Type: CONSTRAINT; Schema: public; Owner: kama
--

ALTER TABLE ONLY public.pp_sample_photos
    ADD CONSTRAINT pp_sample_photos_pkey PRIMARY KEY (id);


--
-- Name: pp_samples pp_samples_pkey; Type: CONSTRAINT; Schema: public; Owner: kama
--

ALTER TABLE ONLY public.pp_samples
    ADD CONSTRAINT pp_samples_pkey PRIMARY KEY (id);


--
-- Name: suppliers suppliers_name_key; Type: CONSTRAINT; Schema: public; Owner: kama
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_name_key UNIQUE (name);


--
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: kama
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: kama
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: kama
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: inspection_issue_photos_inspection_issue_id_index; Type: INDEX; Schema: public; Owner: kama
--

CREATE INDEX inspection_issue_photos_inspection_issue_id_index ON public.inspection_issue_photos USING btree (inspection_issue_id);


--
-- Name: inspection_issues_defect_id_index; Type: INDEX; Schema: public; Owner: kama
--

CREATE INDEX inspection_issues_defect_id_index ON public.inspection_issues USING btree (defect_id);


--
-- Name: inspection_issues_inspection_id_index; Type: INDEX; Schema: public; Owner: kama
--

CREATE INDEX inspection_issues_inspection_id_index ON public.inspection_issues USING btree (inspection_id);


--
-- Name: inspections_created_at_index; Type: INDEX; Schema: public; Owner: kama
--

CREATE INDEX inspections_created_at_index ON public.inspections USING btree (created_at);


--
-- Name: inspections_supplier_id_index; Type: INDEX; Schema: public; Owner: kama
--

CREATE INDEX inspections_supplier_id_index ON public.inspections USING btree (supplier_id);


--
-- Name: pp_sample_photos_pp_sample_id_index; Type: INDEX; Schema: public; Owner: kama
--

CREATE INDEX pp_sample_photos_pp_sample_id_index ON public.pp_sample_photos USING btree (pp_sample_id);


--
-- Name: pp_samples_created_at_index; Type: INDEX; Schema: public; Owner: kama
--

CREATE INDEX pp_samples_created_at_index ON public.pp_samples USING btree (created_at);


--
-- Name: pp_samples_supplier_id_index; Type: INDEX; Schema: public; Owner: kama
--

CREATE INDEX pp_samples_supplier_id_index ON public.pp_samples USING btree (supplier_id);


--
-- Name: inspections inspections_set_updated_at; Type: TRIGGER; Schema: public; Owner: kama
--

CREATE TRIGGER inspections_set_updated_at BEFORE UPDATE ON public.inspections FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: pp_samples pp_samples_set_updated_at; Type: TRIGGER; Schema: public; Owner: kama
--

CREATE TRIGGER pp_samples_set_updated_at BEFORE UPDATE ON public.pp_samples FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: inspection_issue_photos inspection_issue_photos_inspection_issue_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kama
--

ALTER TABLE ONLY public.inspection_issue_photos
    ADD CONSTRAINT inspection_issue_photos_inspection_issue_id_fkey FOREIGN KEY (inspection_issue_id) REFERENCES public.inspection_issues(id) ON DELETE CASCADE;


--
-- Name: inspection_issues inspection_issues_defect_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kama
--

ALTER TABLE ONLY public.inspection_issues
    ADD CONSTRAINT inspection_issues_defect_id_fkey FOREIGN KEY (defect_id) REFERENCES public.defects(id) ON DELETE RESTRICT;


--
-- Name: inspection_issues inspection_issues_inspection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kama
--

ALTER TABLE ONLY public.inspection_issues
    ADD CONSTRAINT inspection_issues_inspection_id_fkey FOREIGN KEY (inspection_id) REFERENCES public.inspections(id) ON DELETE CASCADE;


--
-- Name: inspections inspections_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kama
--

ALTER TABLE ONLY public.inspections
    ADD CONSTRAINT inspections_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: inspections inspections_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kama
--

ALTER TABLE ONLY public.inspections
    ADD CONSTRAINT inspections_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id) ON DELETE RESTRICT;


--
-- Name: pp_sample_photos pp_sample_photos_pp_sample_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kama
--

ALTER TABLE ONLY public.pp_sample_photos
    ADD CONSTRAINT pp_sample_photos_pp_sample_id_fkey FOREIGN KEY (pp_sample_id) REFERENCES public.pp_samples(id) ON DELETE CASCADE;


--
-- Name: pp_samples pp_samples_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kama
--

ALTER TABLE ONLY public.pp_samples
    ADD CONSTRAINT pp_samples_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: pp_samples pp_samples_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kama
--

ALTER TABLE ONLY public.pp_samples
    ADD CONSTRAINT pp_samples_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id) ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict I1KkP1gkcW8Itf9sxMMgm4w0ZxmkphA1RNk3XmVPuNZreVW3m9krgfpOjw5bFnB

